package ch7;

public class CashRegister {
	private double purchase; 
	private double payment;
	public CashRegister() {
		purchase = 0;
		payment = 0;
	}
	
	public void recordPurchase(int coinCount, Coin coinType) {
		purchase = purchase + (coinCount * coinType.getValue());
	}
	
	public void enterPayment(int coinCount, Coin coinType) {
		payment = payment + (coinCount * coinType.getValue());
	}
	
	public double giveChange(Coin coinType) {
		double change =  payment - purchase;
		payment = 0.0;
		purchase = 0.0;
		return change;
	}
}
