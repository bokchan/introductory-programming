package ch11.p16;

public  class RecursiveFibonacciHelper {
	private static long[] fibArray;

	public static void runLoopFibonacci(int n) {
		
		
		for (int i = 1; i <= n; i++)
		{
			long f = fibLoop(i);
			//System.out.println("fib(" + i + ") = " + f);
		}

	}
	
	public static void runRecursiveFibonacci(int n) {
		fibArray = new long[n];
		for (int i = 1; i <= n; i++)
		{
			long f = fibRecursive(i);
			//System.out.println("fib(" + i + ") = " + f);
		}

	}

	public static void runRecursiveBufferedFibonacci(int n) {
		fibArray = new long[n];

		for (int i = 1; i <= n; i++)
		{			 
			long f = fibRecursiveBuffered(i);
			//System.out.println("fib(" + i + ") = " + f);
		}                    
	}
	
	private static long fibRecursive(int n)
	{	
		
		if (n <= 2) {
			fibArray[n-1] = 1;
			return 1;
		}
		else  {
			return fibRecursive(n-2) + fibRecursive(n-1); 	
		} 
	}


	private static long fibRecursiveBuffered(int n)
	{	
		if (n <= 2) {
			fibArray[n-1] = 1;
			return 1;
		}
		else  {
			fibArray[n-1] = fibRecursiveBuffered(n-1);
			return fibArray[n-2] + fibArray[n-1]; 	
		} 
	}

	private static long fibLoop(int n)
	{  
		if (n <= 2) { return 1; }
		long olderValue = 1;
		long oldValue = 1;
		long newValue = 1;
		for (int i = 3; i <= n; i++)
		{  
			newValue = oldValue + olderValue;
			olderValue = oldValue;
			oldValue = newValue;
		}
		return newValue;
	}
}
