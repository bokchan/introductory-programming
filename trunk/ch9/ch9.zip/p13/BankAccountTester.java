package ch9.p13;

import junit.framework.Assert;

import org.junit.Test;

public class BankAccountTester {
	
	@Test
	public void BankAccountTester() {
		
		SavingsAccount savings = new SavingsAccount(3.5);
		TimeDepositAccount timeDeposit= new TimeDepositAccount(1000, 6, 5);
		CheckingAccount checking = new CheckingAccount(10000);
		
		Test(savings);
		System.out.println(savings.getBalance());
		
		Assert.assertEquals(3766.76, 
				savings.getBalance(), 0.5);
		Test(timeDeposit);
		System.out.println(timeDeposit.getBalance());
		Assert.assertEquals(5237.40, 
				timeDeposit.getBalance(), 0.5);
		Test(checking);
		System.out.println(checking.getBalance());
		Assert.assertEquals(13250, 
				checking.getBalance(), 0.5);
		
	} 
	
	public static void Test(BankAccount account) {
		account.deposit(100);
		account.endOfMonth();
		account.deposit(4000);
		account.endOfMonth();
		account.withdraw(600);
		account.endOfMonth();
		account.withdraw(500);
		account.endOfMonth();
		account.deposit(250);
		account.endOfMonth();
	} 
}

/**
 * Regarding the question of abstract classes. 
 * The Bankaccount class is now declared abstract 
 * while its subclasses are concrete   
 */